# Honk Tavern Guestbook — Cloudflare foundation

This is the staged Cloudflare-native backend for the guestbook. The legacy PHP implementation remains untouched during the migration.

## Stack

- Cloudflare Workers
- Cloudflare D1
- Cloudflare Turnstile
- TypeScript
- Native Worker APIs

## Endpoints

- `GET /api/health`
- `GET /api/entries?limit=20&before=<id>`
- `POST /api/entries`

POST expects JSON:

```json
{
  "name": "Visitor Name",
  "message": "A message for the tavern!",
  "turnstileToken": "<token>"
}
```

## Secrets

Set these with Wrangler; do not commit them:

```text
wrangler secret put TURNSTILE_SECRET
wrangler secret put FINGERPRINT_SALT
```

Turnstile requires both a browser widget/sitekey and server-side Siteverify validation. The server must never trust the browser token without validation.

## Migration

```text
wrangler d1 migrations apply honktavern-guestbook --remote
wrangler deploy
```

Use the intended Cloudflare account/project before running the remote commands.

## UI direction

The final interface is an original Honk Tavern open-message-book experience inspired by the interaction model of FFXIV Message Books:

- left page: signing panel + Turnstile gate
- right page: message entries
- book-like pagination/page turns
- original Honk Tavern art/CSS rather than copied game assets
- mobile single-page fallback
- loading skeletons and retry states
- form drafts preserved across recoverable API failures

The Turnstile widget is a security gate inside the signing page, not a replacement for the entire page.

## Legacy note

The existing repository currently contains both PostgreSQL and SQLite persistence paths. They are intentionally not used by this Worker. D1 becomes the intended source of truth after staged cutover.
