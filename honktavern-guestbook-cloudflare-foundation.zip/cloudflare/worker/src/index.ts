interface Env {
  DB: D1Database;
  TURNSTILE_SECRET: string;
  MAX_NAME_LENGTH?: string;
  MAX_MESSAGE_LENGTH?: string;
  DAILY_ENTRY_LIMIT?: string;
  RATE_WINDOW_SECONDS?: string;
  RATE_MAX_REQUESTS?: string;
  FINGERPRINT_SALT?: string;
}

const CORS = {
  "access-control-allow-origin": "*",
  "access-control-allow-methods": "GET,POST,OPTIONS",
  "access-control-allow-headers": "content-type",
};

function json(data: unknown, status = 200) {
  return new Response(JSON.stringify(data), {
    status,
    headers: {
      "content-type": "application/json; charset=utf-8",
      "cache-control": "no-store",
      ...CORS,
    },
  });
}

function numberEnv(env: Env, key: keyof Env, fallback: number) {
  const n = Number(env[key]);
  return Number.isFinite(n) && n > 0 ? n : fallback;
}

async function fingerprint(request: Request, env: Env) {
  const ip = request.headers.get("CF-Connecting-IP") ?? "unknown";
  const salt = env.FINGERPRINT_SALT || env.TURNSTILE_SECRET;
  const bytes = new TextEncoder().encode(`${salt}:${ip}`);
  const digest = await crypto.subtle.digest("SHA-256", bytes);
  return [...new Uint8Array(digest)]
    .map((b) => b.toString(16).padStart(2, "0"))
    .join("");
}

async function verifyTurnstile(token: string, request: Request, env: Env) {
  if (!env.TURNSTILE_SECRET || !token) return false;

  const body = new URLSearchParams({
    secret: env.TURNSTILE_SECRET,
    response: token,
  });

  const ip = request.headers.get("CF-Connecting-IP");
  if (ip) body.set("remoteip", ip);

  const response = await fetch(
    "https://challenges.cloudflare.com/turnstile/v0/siteverify",
    {
      method: "POST",
      headers: { "content-type": "application/x-www-form-urlencoded" },
      body,
    },
  );

  if (!response.ok) return false;
  const result = await response.json() as { success?: boolean };
  return result.success === true;
}

async function consumeRateLimit(env: Env, key: string) {
  const now = Math.floor(Date.now() / 1000);
  const windowSeconds = numberEnv(env, "RATE_WINDOW_SECONDS", 60);
  const maxRequests = numberEnv(env, "RATE_MAX_REQUESTS", 5);

  const row = await env.DB
    .prepare("SELECT window_started_at, request_count FROM rate_limits WHERE key = ?")
    .bind(key)
    .first<{ window_started_at: number; request_count: number }>();

  if (!row || now - row.window_started_at >= windowSeconds) {
    await env.DB
      .prepare(
        "INSERT INTO rate_limits(key, window_started_at, request_count) VALUES (?, ?, 1) " +
        "ON CONFLICT(key) DO UPDATE SET window_started_at=excluded.window_started_at, request_count=1",
      )
      .bind(key, now)
      .run();
    return true;
  }

  if (row.request_count >= maxRequests) return false;

  await env.DB
    .prepare("UPDATE rate_limits SET request_count = request_count + 1 WHERE key = ?")
    .bind(key)
    .run();

  return true;
}

async function listEntries(env: Env, request: Request) {
  const url = new URL(request.url);
  const limit = Math.min(
    Math.max(Number(url.searchParams.get("limit") || "20"), 1),
    50,
  );
  const before = Number(url.searchParams.get("before") || "0");

  const result = before > 0
    ? await env.DB.prepare(
        "SELECT id, name, message, created_at FROM entries " +
        "WHERE status='published' AND id < ? ORDER BY id DESC LIMIT ?",
      ).bind(before, limit).all()
    : await env.DB.prepare(
        "SELECT id, name, message, created_at FROM entries " +
        "WHERE status='published' ORDER BY id DESC LIMIT ?",
      ).bind(limit).all();

  const entries = result.results ?? [];
  const nextCursor = entries.length === limit
    ? entries[entries.length - 1].id
    : null;

  return json({ entries, nextCursor });
}

async function createEntry(env: Env, request: Request) {
  if (!(request.headers.get("content-type") || "").includes("application/json")) {
    return json({ error: "Expected application/json" }, 415);
  }

  const body = await request.json().catch(() => null) as {
    name?: unknown;
    message?: unknown;
    turnstileToken?: unknown;
  } | null;

  const name = typeof body?.name === "string" ? body.name.trim() : "";
  const message = typeof body?.message === "string" ? body.message.trim() : "";
  const token = typeof body?.turnstileToken === "string" ? body.turnstileToken : "";

  const maxName = numberEnv(env, "MAX_NAME_LENGTH", 100);
  const maxMessage = numberEnv(env, "MAX_MESSAGE_LENGTH", 350);

  if (name.length < 2 || name.length > maxName) {
    return json({ error: "Name must be between 2 and 100 characters." }, 400);
  }

  if (message.length < 10 || message.length > maxMessage) {
    return json({ error: "Message must be between 10 and 350 characters." }, 400);
  }

  const fp = await fingerprint(request, env);

  if (!(await consumeRateLimit(env, `submit:${fp}`))) {
    return json({ error: "Please wait before submitting again." }, 429);
  }

  if (!(await verifyTurnstile(token, request, env))) {
    await env.DB
      .prepare("INSERT INTO abuse_events(fingerprint, reason) VALUES (?, ?)")
      .bind(fp, "turnstile_failed")
      .run();
    return json({ error: "Verification failed. Please try again." }, 403);
  }

  const dailyLimit = numberEnv(env, "DAILY_ENTRY_LIMIT", 1);
  const recent = await env.DB
    .prepare(
      "SELECT COUNT(*) AS count FROM entries " +
      "WHERE fingerprint = ? AND created_at >= datetime('now', '-1 day')",
    )
    .bind(fp)
    .first<{ count: number }>();

  if ((recent?.count ?? 0) >= dailyLimit) {
    return json({ error: "You have already signed the guestbook recently." }, 429);
  }

  const createdAt = new Date().toISOString();
  const insert = await env.DB
    .prepare(
      "INSERT INTO entries(name, message, created_at, status, source, fingerprint) " +
      "VALUES (?, ?, ?, 'published', 'web', ?)",
    )
    .bind(name, message, createdAt, fp)
    .run();

  return json(
    { success: true, id: insert.meta.last_row_id, createdAt },
    201,
  );
}

export default {
  async fetch(request: Request, env: Env) {
    if (request.method === "OPTIONS") {
      return new Response(null, { status: 204, headers: CORS });
    }

    const url = new URL(request.url);

    try {
      if (request.method === "GET" && url.pathname === "/api/health") {
        return json({ ok: true, service: "honktavern-guestbook" });
      }

      if (request.method === "GET" && url.pathname === "/api/entries") {
        return listEntries(env, request);
      }

      if (request.method === "POST" && url.pathname === "/api/entries") {
        return createEntry(env, request);
      }

      return json({ error: "Not found" }, 404);
    } catch (error) {
      console.error("guestbook request failed", error);
      return json({ error: "Internal server error" }, 500);
    }
  },
};
