# Guestbook feature backlog

### Core
- Message book UI
- Visitor name
- Message body
- Turnstile verification
- D1 persistence
- Rate limiting
- Cursor pagination
- Accessible loading/error states

### FFXIV-inspired interaction model
- Owner greeting
- Public entries by default
- Optional private entries
- Daily signing cadence
- Likes
- Author/owner deletion

### Honk Tavern identity
- Original tavern visual language
- Goos Hime integration
- Tavern prompts
- Optional character/world field
- Seasonal/event decorations

### Moderation
- Owner-only admin
- Hide/delete/restore
- Abuse-event log
- Audit trail
- Export
- Optional Discord notification

### Future
- Multiple guestbooks
- Event-specific books
- Themes
- Reactions
- Replies
- Search
- Pinned entries

### Engineering rules
1. Never store raw visitor IPs in guestbook records.
2. Never commit Turnstile secrets.
3. Keep moderation states in the schema from day one.
4. Keep read and write paths independently resilient.
5. Do not block the initial UI on the entire API.
6. Avoid framework dependencies until the UI needs one.
7. Treat FFXIV as interaction inspiration, not a source of copied assets.
