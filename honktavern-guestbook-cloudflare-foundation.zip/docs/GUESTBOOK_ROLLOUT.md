# Honk Tavern Guestbook — rollout plan

## Stage 0 — Cloudflare foundation

- Worker API skeleton
- D1 schema/migration
- Turnstile server-side verification
- Hashed visitor fingerprinting; no raw IP storage
- Short-window request limiting
- One-entry-per-24-hours policy, configurable
- Published/hidden/deleted moderation state
- Cursor pagination
- Health endpoint

**Exit:** remote D1 migration succeeds, Worker deploys, health responds, invalid Turnstile tokens cannot create entries.

## Stage 1 — Book shell

- Responsive two-page book
- Left signing page
- Right reading page
- Original Honk Tavern visual treatment
- Loading skeleton
- Empty state
- API error/retry state
- Mobile one-page fallback
- Keyboard/focus accessibility

**Exit:** the book is useful before API data finishes loading.

## Stage 2 — Signing

- Name + message inputs
- Character counter
- Turnstile
- Draft preservation
- Submission progress state
- Success animation
- Rate-limit messaging
- Daily signing rule

**Exit:** visitor can sign and see the new entry without a full reload.

## Stage 3 — Browsing

- Previous/next page controls
- Cursor-based pagination
- Page numbers
- New-entry refresh
- Optional gentle page-turn animation
- Cache/read resilience

**Exit:** browsing feels like a message book, not a feed.

## Stage 4 — Moderation

- Owner authentication
- Hide/unhide
- Delete/restore
- Abuse-event view
- Audit trail
- Export
- Optional Discord notification

**Exit:** all moderation is possible without direct database access.

## Stage 5 — Social features

- Likes/reactions
- Owner greeting
- Optional private entries
- Replies
- Character/world identity
- Seasonal book decorations

**Exit:** social features remain optional modules and do not destabilize signing/reading.

## Stage 6 — Production hardening

- Worker unit/integration tests
- Narrow CORS to production origin
- Content Security Policy
- Error/abuse telemetry
- D1 backup/export process
- Data-retention policy
- Migration rollback procedure
- Deployment smoke tests
- Accessibility pass
- Mobile performance pass

## Stage 7 — Cutover

1. Export any legacy entries worth keeping.
2. Validate/import them into D1.
3. Deploy Worker + frontend.
4. Run read-only verification.
5. Enable signing.
6. Keep legacy read/rollback path briefly.
7. Disable legacy writes.
8. Remove legacy persistence after the retention window.

## Deliberate non-goals

No accounts, Discord OAuth, image uploads, Markdown, AI moderation, WebSockets, or complex analytics in the first release.
